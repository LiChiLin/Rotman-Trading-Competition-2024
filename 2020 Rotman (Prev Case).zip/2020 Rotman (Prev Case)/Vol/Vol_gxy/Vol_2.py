# from volapi import VolCaseClient
from RIT_api_VolCase import VolCaseClient
from py_vollib.black_scholes.implied_volatility import implied_volatility
from py_vollib.black_scholes_merton.greeks.analytical import delta
from stratUlt import *
import numpy as np
import pandas as pd
import re
import time

class Option:
    def __init__(self, opt):
        self.K = int(opt[-2:])
        self.TT = int(opt[3])
        self.straddle = opt[:4] + '_' + opt[-2:]
        self.type = opt[4].lower()

    def T(self, now_tick, period):
        if self.TT == 2:
            return (600/period-now_tick)/15/250
        elif self.TT == 1:
            return (300-now_tick)/15/250

def delta_hedge(diff_delta):
    if diff_delta > 0:
        while diff_delta > 10000:
            api.market_sell("RTM", 10000)
            diff_delta -= 10000
        api.market_sell("RTM", diff_delta)
    elif diff_delta < 0:
        while diff_delta < -10000:
            api.market_buy("RTM", 10000)
            diff_delta += 10000
        api.market_buy("RTM", -diff_delta)


if __name__ == '__main__':
    url = 'http://localhost:9999/v1/'
    apikey = {'X-API-Key': '6D4BPW7Q'}

    opts = {o:Option(o) for o in ava_ticker}

    # Case Params
    r = 0  # risk free rate
    q = 0  # dividend rate
    real_vol = 0.2  # real volatility at the beginning
    prev_id = 0
    options_limit = 800
    stock_limit = 10000
    options_limit_per_order = 100

    # rng_time = np.concatenate(
    #     (np.arange(75, 150), np.arange(225, 300), np.arange(375, 450)))  # efficient predicting zone

    # Strat Params
    alpha = 250  # order intensity
    safe_rng = 0.01  # safe range width
    rng_d = real_vol - safe_rng  # downside safe zone
    rng_u = real_vol + safe_rng  # upside safe zone

    rng_time = []
    for i in range(4):     # 正式比赛把3改成7？
        rng_time.extend(list(np.arange(75*i+37, 75*(i+1)+1)))
    rng_time = np.array(rng_time)

    # Connect and Wait for start
    api = VolCaseClient(url, apikey)

    ###############################################################
    # Connect and Wait for start
    while api.case_status() == False:
        time.sleep(0.2)

    while api.case_status() == True:

        now_tick = api.case_tick()[0][0]
        if now_tick == 0:
            continue
        print('Current time:', now_tick)

        if now_tick not in rng_time:
            time.sleep(3)
            continue

        period = api.case()['period'][0]

        ####### ========================+######
        ##### two-month options #######
        ####### ========================########
        t = opts['RTM2C50'].T(now_tick, period)

        # get data
        pos = api.position()
        pos_ticker = list(pos[pos != 0].index)
        prc_bid = api.price(kind='bid')
        prc_ask = api.price(kind='ask')
        prc_last = api.price(kind='last')
        S_ask = api.price(ticker="RTM", kind='ask')
        S_bid = api.price(ticker="RTM", kind='bid')
        S_last = api.price(ticker="RTM", kind='last')
        call_list = [i for i in ava_ticker if '2C' in i]
        put_list = [i for i in ava_ticker if '2P' in i]

        try:
            vol_news = api.news_kind("Announcement", is_last=True)["body"]
            real_vol = int(re.findall(r"\d+", vol_news.values[0])[0]) / 100
        except:
            pass

        # define safe zone piecewise
        if now_tick + (period - 1) * 300 <= 540:
            rng_d = real_vol - 0.01
            rng_u = real_vol + 0.01
        else:
            rng_d = real_vol - 0.02
            rng_u = real_vol + 0.02

        range_news = api.news_kind("News", is_last=True)["body"]
        try:
            rng_d = int(re.findall(r"\d+", range_news.values[0])[0]) / 100
            rng_u = int(re.findall(r"\d+", range_news.values[0])[1]) / 100
            if rng_d == rng_u:
                rng_d += 0.01
                rng_u -= 0.01
        except:
            pass

        # computation -- implied vol
        vol_dict = {}
        nan_count = []
        for opt in call_list + put_list:
            try:
                if opts[opt].type == 'c':
                    iv = implied_volatility(prc_last[opt], S_last, opts[opt].K+0.02, t, r=0, flag=opts[opt].type)
                else:
                    iv = implied_volatility(prc_last[opt], S_last, opts[opt].K-0.02, t, r=0, flag=opts[opt].type)
            except Exception:
                iv = np.nan
                nan_count.append(opt)
            vol_dict[opt] = iv
        iv_s = pd.Series(vol_dict)

        # find at-the-money option and its iv
        at_money_opt = []
        for i in iv_s.index:
            if str(int(round(S_last))) in i:
                at_money_opt.append(i)
        now_iv = iv_s[at_money_opt].mean()
        print("2 month: rv =", real_vol, "iv =", round(now_iv, 2), "safe range", round(rng_d, 2), "~",
              round(rng_u, 2))

        ## if iv is beyong the upper bound, sell the straddle
        opt_pos = abs(api.position().iloc[1:].sum())
        if (now_iv > rng_u) & (opt_pos < options_limit):
            amount = min(int((now_iv - rng_u) / 0.1 * alpha + 1), options_limit_per_order)
            for opt in at_money_opt:
                api.market_sell(opt, amount)
            exec_prc = prc_bid[at_money_opt].sum()
            print("sell straddle at", round(exec_prc, 2), "by", amount)

        elif (now_iv < rng_d) & (opt_pos < options_limit):
            amount = min(int((rng_d - now_iv) / 0.1 * alpha + 1), options_limit_per_order)
            for opt in at_money_opt:
                api.market_buy(opt, amount)
            exec_prc = prc_ask[at_money_opt].sum()
            print("buy straddle at", round(exec_prc, 2), "by", amount)

            # print('start guessing volatility skew')

            in_money_call = []
            for i in iv_s.index:
                if ((int(round(S_last)) - 2 <= opts[i].K) & (int(round(S_last))) > opts[i].K) & (opts[i].type == 'c'):
                    in_money_call.append(i)

            for opt in in_money_call:
                opts = [opt, c2p_dict[opt]]
                now_iv = iv_s[opts].mean()
                if now_iv < rng_d:
                    amount = min(int((rng_d - now_iv) / 0.1 * alpha), options_limit_per_order)
                    api.market_buy(opt, amount)
                    api.market_buy(c2p_dict[opt], amount)
                    exec_prc = prc_ask[opts].sum()
                    print("buy straddle", opt, " at", round(exec_prc, 2), "by", amount)
                elif (now_iv >= rng_d) & (opt in pos_ticker):
                    for ticker in opts:
                        api.close_pos(ticker)
                        print("close", ticker, "by", amount)

        elif (now_iv <= rng_u) & (now_iv >= rng_d):
            for ticker in iv_s.index.tolist():
                if ticker in pos_ticker:
                    amount = api.close_pos(ticker)
                    print("close", ticker, "by", amount)

        ####### ========================+######
        ##### one-month options #######
        ####### ========================########

        # t1 = (300 - now_tick - (api.case_tick()[0][2] - 1) * 300) / 300 / 12  # time to maturity
        # if t1 > 0:
        if period == 1:

            t1 = opts['RTM1C50'].T(now_tick, period)

            # get data
            pos = api.position()
            pos_ticker = list(pos[pos != 0].index)
            prc_bid = api.price(kind='bid')
            prc_ask = api.price(kind='ask')
            prc_last = api.price(kind='last')
            S_ask = api.price(ticker="RTM", kind='ask')
            S_bid = api.price(ticker="RTM", kind='bid')
            S_last = api.price(ticker="RTM", kind='last')
            call_list = [i for i in ava_ticker if '1C' in i]
            put_list = [i for i in ava_ticker if '1P' in i]

            # computation -- implied vol
            vol_dict = {}
            nan_count = []
            for opt in call_list + put_list:
                try:
                    iv = implied_volatility(prc_last[opt], S_last, opts[opt].K, t1, r, opts[opt].type)
                except Exception:
                    iv = np.nan
                    nan_count.append(opt)
                vol_dict[opt] = iv
            iv_s1 = pd.Series(vol_dict)

            # find at-the-money option and its iv
            at_money_opt = []
            for i in iv_s1.index:
                if (str(int(round(S_last))) in i):
                    at_money_opt.append(i)
            now_iv = iv_s1[at_money_opt].mean()
            print("1 month: rv =", real_vol, "iv =", round(now_iv, 2), "safe range", round(rng_d, 2), "~",
                  round(rng_u, 2))

            ## if iv is beyong the upper bound
            opt_pos = abs(api.position().iloc[1:].sum())
            if (now_iv > rng_u) & (opt_pos < options_limit):
                amount = min(int((now_iv - rng_u) / 0.1 * alpha + 1), options_limit_per_order)
                for opt in at_money_opt:
                    api.market_sell(opt, amount)
                exec_prc = prc_bid[at_money_opt].sum()
                print("sell straddle at", round(exec_prc, 2), "by", amount)

            elif (now_iv < rng_d) & (opt_pos < options_limit):
                amount = min(int((rng_d - now_iv) / 0.1 * alpha + 1), options_limit_per_order)
                for opt in at_money_opt:
                    api.market_buy(opt, amount)
                exec_prc = prc_ask[at_money_opt].sum()
                print("buy straddle at", round(exec_prc, 2), "by", amount)

                #print('start guessing volatility skew')
                in_money_call = []
                for i in iv_s1.index:
                    if ((int(round(S_last)) - 2 <= opts[i].K) & (int(round(S_last))) > opts[i].K) & (
                            opts[i].type == 'c'):
                        in_money_call.append(i)

                for opt in in_money_call:
                    opts = [opt, c2p_dict[opt]]
                    now_iv = iv_s1[opts].mean()
                    if now_iv < rng_d:
                        amount = min(int((rng_d - now_iv) / 0.1 * alpha), options_limit_per_order)
                        api.market_buy(opt, amount)
                        api.market_buy(c2p_dict[opt], amount)
                        exec_prc = prc_ask[opts].sum()
                        print("buy straddle", opt, " at", round(exec_prc, 2), "by", amount)
                    elif (now_iv >= rng_d) & (opt in pos_ticker):
                        for ticker in opts:
                            api.close_pos(ticker)
                            print("close", ticker, "by", amount)

            elif (now_iv <= rng_u) & (now_iv >= rng_d):
                for ticker in iv_s1.index.tolist():
                    if ticker in pos_ticker:
                        amount = api.close_pos(ticker)
                        print("close", ticker, "by", amount)

        # delta hedge
        prev_delta = - api.position()['RTM']
        pos = api.position().drop('RTM')
        pos_ticker = list(pos[pos!=0].index)
        new_delta = 0

        for ticker in pos_ticker:
            if opts[ticker].TT == 1:
                sigma = iv_s1[ticker]
            else:
                sigma = iv_s[ticker]
            opt_delta = delta(opts[ticker].type, S_last, opts[ticker].K, opts[ticker].T(now_tick, period), r, sigma, q)
            new_delta += opt_delta * pos[ticker] * 100
        diff_delta = new_delta - prev_delta

        delta_hedge(diff_delta)
        prev_delta = new_delta

        time.sleep(2)



