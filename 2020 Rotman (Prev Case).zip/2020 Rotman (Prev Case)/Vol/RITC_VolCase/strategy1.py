from RIT_api_VolCase import VolCaseClient
from apiUlt import url, apikey
from stratUlt import * # c2p_dict, p2c_dict
from py_vollib.black_scholes.implied_volatility import implied_volatility
from py_vollib.black_scholes_merton.greeks.analytical import delta
import numpy as np
import pandas as pd
import re 
import time 

def cal_iv(opt, S_last, flag):
    K = int(opt[-2:])
    t = int(opt[3]) / 12
    try:
        iv = implied_volatility(prc_last[opt], S_last, K, t, r=0, flag=flag)
    except Exception:
        iv = 0
    return iv

def delta_hedge(diff_delta):
    if diff_delta > 0:
        while diff_delta > 10000:
            api.market_sell("RTM", 10000)
            diff_delta -= 10000
        api.market_sell("RTM", diff_delta)
    elif diff_delta < 0:
        while diff_delta < -10000:
            api.market_buy("RTM", 10000)
            diff_delta += 10000
        api.market_buy("RTM", -diff_delta)


if __name__ == '__main__':

    # Case Params
    r = 0   # risk free rate
    q = 0   # dividend rate
    real_vol = 0.2 # real volatility at the beginning

    # 测试服每轮只有300秒！
    rng_time = [] # efficient predicting zone
    for i in range(3):     # 正式把3改成7？
        rng_time.extend(list(np.arange(75*i+37, 75*(i+1)+1)))
    rng_time = np.array(rng_time)

    # Strat Params
    alpha = 25 # order intensity
    safe_rng = 0.01 # safe range width
    rng_d = real_vol - safe_rng # downside safe zone
    rng_u = real_vol + safe_rng # upside safe zone
    prev_delta = 0

    call_list = [i for i in ava_ticker if 'C' in i]
    put_list = [i for i in ava_ticker if 'P' in i]

    # Connect and Wait for start
    api = VolCaseClient(url, apikey)
    while api.case_status() == False:
        time.sleep(0.2)

    # Case begins
    now_tick = api.case_tick()[0][0]
    while api.case_status() == True:

        # skip same tick
        if api.case_tick()[0][0] == now_tick:
            continue
        else:
            now_tick = api.case_tick()[0][0]

        print('Current tick:', now_tick)
        # t = (600 - now_tick)/ 30/ 252 # time to maturity
        # t = 1/12

        # get data
        pos = api.position()
        pos_ticker = list(pos[pos!=0].index) # 现在手头不为0的仓位 （会把现货也包括进去）
        prc_bid = api.price(kind='bid') # 所有ticker的series
        prc_ask = api.price(kind='ask')
        prc_last = api.price(kind='last')
        S_ask = api.price(ticker="RTM",kind='ask')
        S_bid = api.price(ticker="RTM",kind='bid')
        S_last = api.price(ticker="RTM",kind='last')

        # get news
        try:
            vol_news = api.news_kind("Announcement",is_last=True)["body"]
            real_vol = int(re.findall(r"\d+", vol_news.values[0])[0]) / 100
        except:
            pass

        # define safe zone piecewise
        # if now_tick <= 225:
        rng_d = real_vol - 0.01
        rng_u = real_vol + 0.01
        # else:
        #     # 在最后一个rv公布结束后
        #     rng_d = real_vol - 0.15
        #     rng_u = real_vol + 0.15
        if now_tick in rng_time:
            range_news = api.news_kind("News",is_last=True)["body"]
            rng_d = int(re.findall(r"\d+", range_news.values[0])[0]) / 100
            rng_u = int(re.findall(r"\d+", range_news.values[0])[1]) / 100
            # print('xxx', rng_d)

        # computation -- implied vol
        vol_dict = {}
        for call in call_list:
            iv = cal_iv(call, S_last, 'c')
            vol_dict[call] = iv
        for put in put_list:
            iv = cal_iv(put, S_last, 'p')
            vol_dict[put] = iv
        iv_s = pd.Series(vol_dict)

        # find at-the-money option and its iv
        at_money_opt = []
        for i in iv_s.index:
            if str(int(round(S_last))) in i:
                at_money_opt.append(i)
        now_iv = iv_s[at_money_opt].mean()
        print("rv =", real_vol,  "iv =", round(now_iv,2), "safe range", round(rng_d,2), "~", round(rng_u,2))

        # according to the range, buy/sell the straddle
        if now_iv > rng_u:
            amount = int((now_iv - rng_u)/0.1*alpha+1)
            for opt in at_money_opt:
                api.market_sell(opt, amount)
            exec_prc = prc_bid[at_money_opt].sum() # two option's price
            straddle_name = at_money_opt[0][0:4] + '_' + at_money_opt[0][-2:]
            print("sell ", straddle_name, " straddle at", round(exec_prc,2), "by", amount)

        elif now_iv < rng_d:
            amount =int((rng_d - now_iv)/0.1*alpha+1)
            for opt in at_money_opt:
                api.market_buy(opt, amount)
            exec_prc = prc_ask[at_money_opt].sum()
            straddle_name = at_money_opt[0][0:4] + '_' + at_money_opt[0][-2:]
            print("buy ", straddle_name, " straddle at", round(exec_prc,2), "by", amount)

        # see if any position can be closed
        for ticker_C in pos_ticker:
            if 'C' in ticker_C:
                ticker_P = c2p_dict[ticker_C]
                iv = (vol_dict[ticker_C] + vol_dict[ticker_P])/2
                if rng_d < iv < rng_u:
                    api.close_pos(ticker_C)
                    amount = api.close_pos(ticker_P)
                    straddle_name = ticker_C[0:4] + '_' + ticker_C[-2:]
                    print("close", straddle_name, "by", amount)
            else:
                continue


        # delta hedge
        pos = api.position()
        pos_ticker = list(pos[pos!=0].index)
        new_delta = 0

        for opt_ticker in pos_ticker:

            if 'C' in opt_ticker:
                flag = 'c'
            elif 'P' in opt_ticker:
                flag = 'p'
            else:
                continue

            K = int(opt_ticker[-2:])
            t = int(opt_ticker[3]) / 12
            sigma = iv_s[opt_ticker]
            opt_delta = delta(flag, S_last, K, t, r, sigma, q)
            new_delta += opt_delta * pos[opt_ticker] * 100

        diff_delta = new_delta - prev_delta
        delta_hedge(diff_delta)

        prev_delta = new_delta

        time.sleep(2)
