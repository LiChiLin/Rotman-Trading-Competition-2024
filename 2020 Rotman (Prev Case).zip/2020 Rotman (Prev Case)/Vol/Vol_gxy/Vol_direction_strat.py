"""
Created on 2020/2/8 10:46
Author: Xinyu Guo
Email: xyguo@bu.edu
IDE: PyCharm
"""

from RIT_api_VolCase import VolCaseClient
from apiUlt import url, apikey
from stratUlt import c2p_dict, p2c_dict, ava_ticker
from py_vollib.black_scholes.implied_volatility import implied_volatility
from py_vollib.black_scholes_merton.greeks.analytical import delta
import numpy as np
import pandas as pd
import re 
import time 

def cal_iv(ticker, S_last, now_tick, period):
    K = opt[ticker].K
    t = opt[ticker].T(now_tick, period)
    flag = opt[ticker].type.lower()
    try:
        iv = implied_volatility(prc_last[ticker], S_last, K, t, r=0, flag=flag)
    except Exception:
        iv = 0
    return iv

def delta_hedge(diff_delta):
    if diff_delta > 0:
        while diff_delta > 10000:
            api.market_sell("RTM", 10000)
            diff_delta -= 10000
        api.market_sell("RTM", diff_delta)
    elif diff_delta < 0:
        while diff_delta < -10000:
            api.market_buy("RTM", 10000)
            diff_delta += 10000
        api.market_buy("RTM", -diff_delta)

class Vol_Calculate():
    def __init__(self, api, vol_n):
        self.vol_history = []
        self.price = pd.Series()
        self.api = api
        self.vol_n = vol_n
        self.ratio = 1

    def cal_vol(self, rv, flag):
        p = self.api.history('RTM', limit=self.vol_n)['close']
        self.price = pd.concat([self.price, p], axis=0).drop_duplicates()

        if len(self.price) >= self.vol_n:
            temp = self.price[-self.vol_n:].pct_change()**2
            # vol = temp * np.sqrt(252)
            vol = np.sqrt(temp.dropna().sum())*np.sqrt(252)

            # When new rv is announced, reset the ratio
            if flag:
                self.ratio = rv / vol
                print('*********** Reset the ratio to {} ************'.format(self.ratio))

            vol = vol*self.ratio
            self.vol_history.append(vol)

            return vol
        else:
            return False

    # def cal_vol_range(self, rv, flag):
    #     vol_t = self.cal_vol(rv, flag)
    #     if vol_t:
    #         vol_std = np.std(self.vol_history[-std_n:])
    #         rv_up = vol_t + 0.02 #self.width*vol_std
    #         rv_down = vol_t - 0.02 #self.width*vol_std
    #         return round(vol_t,2), rv_up, rv_down
    #     else:
    #         return False

class Option:
    def __init__(self, opt):
        self.K = int(opt[-2:])
        self.TT = int(opt[3])
        self.straddle = opt[:4] + '_' + opt[-2:]
        self.type = opt[4]

    def T(self, now_tick, period):
        if self.TT == 2:
            return (600/period-now_tick)/15/250
        elif self.TT == 1:
            return (300-now_tick)/15/250

if __name__ == '__main__':

    # Connect to API
    api = VolCaseClient(url, apikey)

    # Case Params
    r = 0   # risk free rate
    q = 0   # dividend rate
    rv = 0.2 # real vol at start
    opt = {o:Option(o) for o in ava_ticker}
    call_list = [i for i in ava_ticker if 'C' in i]
    put_list = [i for i in ava_ticker if 'P' in i]
    prev_id = 0
    prev_id_pred = 0

    # Strat Params
    alpha = 25 # order intensity
    pos_limit = 80

    vol_n = 16 # 15 seconds is one true day
    # std_n = 10
    # width = 1
    prev_delta = 0
    flag = False
    VolCal = Vol_Calculate(api, vol_n)



    # 测试服每轮只有300秒！
    # efficient predicting zone
    rng_time = []
    for i in range(3):     # 正式比赛把3改成7？
        rng_time.extend(list(np.arange(75*i+37, 75*(i+1)+1)))
    rng_time = np.array(rng_time)

    ###############################################################
    # Connect and Wait for start
    while api.case_status() == False:
        time.sleep(0.2)

    # Case begins
    while api.case_status() == True:

        now_tick = api.case_tick()[0][0]
        print('\nCurrent tick:', now_tick)
        period = api.case()['period'][0]

        # Get Realized Volatility from news
        try:
            id = api.news_kind("Announcement", is_last=True).index[0]
            vol_news = api.news_kind("Announcement",is_last=True)["body"]
            if id > prev_id:
                rv = int(re.findall(r"\d+", vol_news.values[0])[0]) / 100
                print('********** Realized Vol:{} ************'.format(rv))
                prev_id = id
                flag = True
            else:
                flag = False
        except:
            pass

        # Calculate the realized volatility
        rv = VolCal.cal_vol(rv, flag)

        if now_tick in rng_time:
            id_pred = api.news_kind("News", is_last=True).index[0]
            range_news = api.news_kind("News",is_last=True)["body"]
            if id_pred > prev_id_pred:
                predv_d = int(re.findall(r"\d+", range_news.values[0])[0]) / 100
                predv_u = int(re.findall(r"\d+", range_news.values[0])[1]) / 100
                predv_m = (predv_d+predv_u)/2





        # Get price & position data
        pos = api.position()
        pos_ticker = list(pos[pos != 0].index)  # 现在手头不为0的仓位 （会把现货也包括进去）
        prc_bid = api.price(kind='bid')  # 所有ticker的series
        prc_ask = api.price(kind='ask')
        prc_last = api.price(kind='last')
        S_ask = api.price(ticker="RTM", kind='ask')
        S_bid = api.price(ticker="RTM", kind='bid')
        S_last = api.price(ticker="RTM", kind='last')

        # computation -- implied vol
        vol_dict = {opt: cal_iv(opt, S_last, now_tick, period) for opt in ava_ticker}
        iv_s = pd.Series(vol_dict)

        # Find at-the-money option and its iv
        # Consider both 1 month and 2 month
        ATM_opt = []
        for ticker in iv_s.index:
            if period == 2:
                if opt[ticker].TT == 1:
                    continue

            if str(int(round(S_last))) in ticker:
                ATM_opt.append(ticker)

        # See if any option position can be closed
        for ticker in pos_ticker:
            if ticker != 'RTM':
                if 'C' in ticker:
                    ticker_P = c2p_dict[ticker]
                    iv = (vol_dict[ticker] + vol_dict[ticker_P])/2
                    if rv_down < iv < rv_up:
                        api.close_pos(ticker)
                        amount = api.close_pos(ticker_P)
                        print("close", opt[ticker].straddle, "by", amount)
                else:
                    continue

        # According to the range, buy/sell the straddle
        # Condition: Only considering the options whose position doesn't exceed the limit
        for ticker in ATM_opt:
            if opt[ticker].type == 'C':
                ticker_P = c2p_dict[ticker]
                now_iv = (vol_dict[ticker] + vol_dict[ticker_P])/2
                print("rv =", rv, ',',opt[ticker].straddle, "'s iv =", round(now_iv, 2), "safe range", round(rv_down, 2), "~",
                      round(rv_up, 2))
                if abs(pos[ticker]) <= pos_limit: # ticker not in pos_ticker or
                    if now_iv > rv_up:
                        amount = int((now_iv - rv_up) / 0.1 * alpha + 1)
                        api.market_sell(ticker, amount)
                        api.market_sell(ticker_P, amount)
                        exec_prc = prc_ask[[ticker, ticker_P]].sum()
                        print("sell ", opt[ticker].straddle, " straddle at", round(exec_prc, 2), "by", amount)
                    elif now_iv < rv_down:
                        amount = int((rv_down - now_iv) / 0.1 * alpha + 1)
                        api.market_buy(ticker, amount)
                        api.market_buy(ticker_P, amount)
                        exec_prc = prc_bid[[ticker, ticker_P]].sum()  # two option's price
                        print("buy ", opt[ticker].straddle, " straddle at", round(exec_prc, 2), "by", amount)
            else:
                continue
                # print('Cannot buy {}.Already reaches position limit'.format(opt[ticker].straddle))

        # delta hedge
        pos = api.position().drop('RTM')
        pos_ticker = list(pos[pos!=0].index)
        new_delta = 0

        for ticker in pos_ticker:
            sigma = iv_s[ticker]
            opt_delta = delta(opt[ticker].type, S_last, opt[ticker].K, opt[ticker].T(now_tick, period), r, sigma, q)
            new_delta += opt_delta * pos[ticker] * 100
        diff_delta = new_delta - prev_delta

        delta_hedge(diff_delta)
        prev_delta = new_delta

        time.sleep(2)
