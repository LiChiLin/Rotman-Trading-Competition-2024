"""
Created on 2020/2/12 20:22
Author: Xinyu Guo
Email: xyguo@bu.edu
IDE: PyCharm
"""

import time
import pandas as pd
from RIT_api_v1 import *
from RIT_api_VolCase import *
import re

def get_news_data(ritc, vol, count):
    rv = {}
    rd = {}
    ru = {}
    while ritc.case_status() == False:
        time.sleep(0.2)

    while ritc.case_tick()[0][0] != 1:
        time.sleep(0.2)

    print('Start Catching')
    while ritc.case_status() == True:
        try:
            vol_news = vol.news_kind("Announcement", is_last=True)["body"]
            real_vol = int(re.findall(r"\d+", vol_news.values[0])[0]) / 100
            rv_id = vol_news.index[0]

            if rv_id not in rv:
                rv[rv_id] = real_vol
                print(rv_id, vol_news.values[0])
        except:
            pass

        try:
            range_news = vol.news_kind("News", is_last=True)["body"]
            rng_d = int(re.findall(r"\d+", range_news.values[0])[0]) / 100
            rng_u = int(re.findall(r"\d+", range_news.values[0])[1]) / 100
            rng_id = range_news.index[0]
            if rng_id not in ru:
                ru[rng_id] = rng_u
                rd[rng_id] = rng_d
                print(rng_id, range_news.values[0])
        except:
            pass

        time.sleep(10)

    rv_s = pd.Series(rv)
    ru_s = pd.Series(ru)
    rd_s = pd.Series(rd)
    rv_s.index = range(2, 9)
    ru_s.index = range(2, 9)
    rd_s.index = range(2, 9)

    news_df = pd.concat([rv_s, ru_s, rd_s], axis=1)
    news_df.columns = ['rv', 'rd', 'ru']

    news_df.to_csv(r'C:\Users\PC\Desktop\RITC\Vol\TEST_DATA\News_data_{}.csv'.format(count))
    print('Data Downloaded')

if __name__ == '__main__':

    url = 'http://localhost:9999/v1/'
    keyheader = {'X-API-key': '6D4BPW7Q'}
    ritc = RitClient(url, keyheader)
    vol = VolCaseClient(url, keyheader)

    count = 6
    while True:
        get_news_data(ritc, vol, count)
        count += 1