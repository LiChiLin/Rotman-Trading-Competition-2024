"""
Created on 2020/2/12 14:36
Author: Xinyu Guo
Email: xyguo@bu.edu
IDE: PyCharm
"""

import time
import pandas as pd
from RIT_api_v1 import *

def get_tick_data(ritc, count):

    while ritc.case_status() == False:
        time.sleep(0.2)
    #
    while ritc.case_tick()[0][0] != 1:
        time.sleep(0.2)

    tickers1 = list(ritc.securities().index)
    tickers2 = [tickers1[0]] + tickers1[21:]

    df1 = pd.DataFrame(columns = tickers1)

    print('Start Catching')
    while ritc.case_status() == True:
        if ritc.case_tick()[0][0] == 298:
            for ticker in tickers1:
                s = ritc.history(ticker)['close'][:298]
                s.name = ticker
                df1[ticker] = s
            break
        time.sleep(0.3)

    print('First Period End')
    time.sleep(20)

    df2 = pd.DataFrame(columns = tickers2)
    while ritc.case_status() == True:
        if ritc.case_tick()[0][0] == 298:
            for ticker in tickers2:
                s = ritc.history(ticker)['close'][:298]
                s.name = ticker
                df2[ticker] = s
            break
        time.sleep(0.3)
    print('Second Period End')

    df1.sort_index(inplace=True)
    df2.sort_index(inplace=True)

    df1.loc[299] = df1.loc[298]
    df1.loc[300] = df1.loc[299]
    df2.loc[599] = df2.loc[598]
    df2.loc[600] = df2.loc[599]

    df = pd.concat([df1, df2])


    df.to_csv(r'C:\Users\PC\Desktop\RITC\Vol\TEST_DATA\Tick_data_{}.csv'.format(count))
    print('Data Downloaded')
    time.sleep(10)


if __name__ == '__main__':

    url = 'http://localhost:9999/v1/'
    keyheader = {'X-API-key': '6D4BPW7Q'}
    ritc = RitClient(url, keyheader)

    count = 6
    while True:
        get_tick_data(ritc, count)
        count += 1



